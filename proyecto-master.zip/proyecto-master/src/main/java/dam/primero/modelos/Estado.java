package dam.primero.modelos;

public enum Estado {
Disponible, Prestado
}
